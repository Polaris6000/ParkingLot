package com.parking.dao;

import com.parking.vo.FeePolicy;
import com.parking.vo.SalesStats;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 관리자 대시보드 DAO (Data Access Object)
 * 요금 정책 관리 및 매출 통계 조회
 */
public class AdminDAO {
    private Connection conn;
    
    // DB 연결 정보
    private static final String URL = "jdbc:mariadb://localhost:3306/parking_lot";
    private static final String USER = "admin";
    private static final String PASSWORD = "8282";
    
    // DB 연결
    private void connect() throws SQLException {
        if (conn == null || conn.isClosed()) {
            try {
                Class.forName("org.mariadb.jdbc.Driver");
                conn = DriverManager.getConnection(URL, USER, PASSWORD);
            } catch (ClassNotFoundException e) {
                throw new SQLException("MariaDB 드라이버를 찾을 수 없습니다.", e);
            }
        }
    }
    
    // DB 연결 해제
    private void disconnect() {
        try {
            if (conn != null && !conn.isClosed()) {
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    // ===== 1. 요금 정책 관리 =====
    
    /**
     * 현재 요금 정책 조회
     */
    public FeePolicy getCurrentFeePolicy() throws SQLException {
        connect();
        FeePolicy policy = null;
        String sql = "SELECT * FROM fee_policy ORDER BY id DESC LIMIT 1";
        
        try (PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            
            if (rs.next()) {
                policy = new FeePolicy();
                policy.setId(rs.getInt("id"));
                policy.setBaseFee(rs.getInt("base_fee"));
                policy.setBasicUnitMinute(rs.getInt("basic_unit_minute"));
                policy.setUnitFee(rs.getInt("unit_fee"));
                policy.setBillingUnitMinutes(rs.getInt("billing_unit_minutes"));
                policy.setHelpDiscountRate(rs.getInt("help_discount_rate"));
                policy.setCompactDiscountRate(rs.getInt("compact_discount_rate"));
                policy.setGracePeriodMinutes(rs.getInt("grace_period_minutes"));
                policy.setMaxCapAmount(rs.getInt("max_cap_amount"));
                
                Timestamp timestamp = rs.getTimestamp("update_date");
                if (timestamp != null) {
                    policy.setUpdateDate(timestamp.toLocalDateTime());
                }
            }
        } finally {
            disconnect();
        }
        
        return policy;
    }
    
    /**
     * 요금 정책 수정
     */
    public boolean updateFeePolicy(FeePolicy policy) throws SQLException {
        connect();
        String sql = "UPDATE fee_policy SET " +
                     "base_fee = ?, " +
                     "basic_unit_minute = ?, " +
                     "unit_fee = ?, " +
                     "billing_unit_minutes = ?, " +
                     "help_discount_rate = ?, " +
                     "compact_discount_rate = ?, " +
                     "grace_period_minutes = ?, " +
                     "max_cap_amount = ?, " +
                     "update_date = NOW() " +
                     "WHERE id = ?";
        
        try (PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setInt(1, policy.getBaseFee());
            pstmt.setInt(2, policy.getBasicUnitMinute());
            pstmt.setInt(3, policy.getUnitFee());
            pstmt.setInt(4, policy.getBillingUnitMinutes());
            pstmt.setInt(5, policy.getHelpDiscountRate());
            pstmt.setInt(6, policy.getCompactDiscountRate());
            pstmt.setInt(7, policy.getGracePeriodMinutes());
            pstmt.setInt(8, policy.getMaxCapAmount());
            pstmt.setInt(9, policy.getId());
            
            int result = pstmt.executeUpdate();
            return result > 0;
        } finally {
            disconnect();
        }
    }
    
    // ===== 2. 매출 통계 =====
    
    /**
     * 일별 매출 통계 (최근 30일)
     */
    public List<SalesStats> getDailySales() throws SQLException {
        connect();
        List<SalesStats> salesList = new ArrayList<>();
        
        String sql = "SELECT " +
                     "  DATE_FORMAT(pay_time, '%Y-%m-%d') as period, " +
                     "  SUM(pay_log) as total_amount, " +
                     "  COUNT(*) as total_count " +
                     "FROM pay_logs " +
                     "WHERE pay_time >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) " +
                     "GROUP BY DATE_FORMAT(pay_time, '%Y-%m-%d') " +
                     "ORDER BY period DESC";
        
        try (PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            
            while (rs.next()) {
                SalesStats stats = new SalesStats(
                    rs.getString("period"),
                    rs.getInt("total_amount"),
                    rs.getInt("total_count")
                );
                salesList.add(stats);
            }
        } finally {
            disconnect();
        }
        
        return salesList;
    }
    
    /**
     * 월별 매출 통계 (최근 12개월)
     */
    public List<SalesStats> getMonthlySales() throws SQLException {
        connect();
        List<SalesStats> salesList = new ArrayList<>();
        
        String sql = "SELECT " +
                     "  DATE_FORMAT(pay_time, '%Y-%m') as period, " +
                     "  SUM(pay_log) as total_amount, " +
                     "  COUNT(*) as total_count " +
                     "FROM pay_logs " +
                     "WHERE pay_time >= DATE_SUB(CURDATE(), INTERVAL 12 MONTH) " +
                     "GROUP BY DATE_FORMAT(pay_time, '%Y-%m') " +
                     "ORDER BY period DESC";
        
        try (PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            
            while (rs.next()) {
                SalesStats stats = new SalesStats(
                    rs.getString("period"),
                    rs.getInt("total_amount"),
                    rs.getInt("total_count")
                );
                salesList.add(stats);
            }
        } finally {
            disconnect();
        }
        
        return salesList;
    }
    
    /**
     * 차종별 비율 통계
     */
    public Map<String, Integer> getVehicleTypeStats() throws SQLException {
        connect();
        Map<String, Integer> stats = new HashMap<>();
        
        String sql = "SELECT " +
                     "  kind_of_discount, " +
                     "  COUNT(*) as count " +
                     "FROM pay_logs " +
                     "WHERE pay_time >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) " +
                     "GROUP BY kind_of_discount";
        
        try (PreparedStatement pstmt = conn.prepareStatement(sql);
             ResultSet rs = pstmt.executeQuery()) {
            
            // 초기화
            stats.put("normal", 0);
            stats.put("light", 0);
            stats.put("disabled", 0);
            stats.put("monthly", 0);
            
            while (rs.next()) {
                String type = rs.getString("kind_of_discount");
                int count = rs.getInt("count");
                
                if (type != null) {
                    stats.put(type, count);
                }
            }
        } finally {
            disconnect();
        }
        
        return stats;
    }
    
    /**
     * 전체 통계 요약 (오늘/이번달/전체)
     */
    public Map<String, Object> getSummaryStats() throws SQLException {
        connect();
        Map<String, Object> summary = new HashMap<>();
        
        try {
            // 오늘 매출
            String todaySql = "SELECT SUM(pay_log) as amount, COUNT(*) as count " +
                             "FROM pay_logs WHERE DATE(pay_time) = CURDATE()";
            try (PreparedStatement pstmt = conn.prepareStatement(todaySql);
                 ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    summary.put("todayAmount", rs.getInt("amount"));
                    summary.put("todayCount", rs.getInt("count"));
                }
            }
            
            // 이번달 매출
            String monthSql = "SELECT SUM(pay_log) as amount, COUNT(*) as count " +
                             "FROM pay_logs WHERE DATE_FORMAT(pay_time, '%Y-%m') = DATE_FORMAT(CURDATE(), '%Y-%m')";
            try (PreparedStatement pstmt = conn.prepareStatement(monthSql);
                 ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    summary.put("monthAmount", rs.getInt("amount"));
                    summary.put("monthCount", rs.getInt("count"));
                }
            }
            
            // 전체 매출
            String totalSql = "SELECT SUM(pay_log) as amount, COUNT(*) as count FROM pay_logs";
            try (PreparedStatement pstmt = conn.prepareStatement(totalSql);
                 ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    summary.put("totalAmount", rs.getInt("amount"));
                    summary.put("totalCount", rs.getInt("count"));
                }
            }
            
            // 현재 주차 중인 차량 수
            String parkingSql = "SELECT COUNT(*) as count FROM parking_times WHERE exit_time IS NULL";
            try (PreparedStatement pstmt = conn.prepareStatement(parkingSql);
                 ResultSet rs = pstmt.executeQuery()) {
                if (rs.next()) {
                    summary.put("currentParking", rs.getInt("count"));
                }
            }
            
        } finally {
            disconnect();
        }
        
        return summary;
    }
}
