package com.parking.controller;

import com.parking.dao.AdminDAO;
import com.parking.vo.FeePolicy;
import com.parking.vo.SalesStats;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

/**
 * 관리자 대시보드 Servlet
 * URL 패턴: /admin/*
 */
@WebServlet("/admin/*")
public class AdminServlet extends HttpServlet {
    private AdminDAO adminDAO;
    
    @Override
    public void init() throws ServletException {
        adminDAO = new AdminDAO();
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");
        
        // 세션 체크 (관리자 권한 확인)
        HttpSession session = request.getSession();
        String authorization = (String) session.getAttribute("authorization");
        
        if (authorization == null || !authorization.equals("master")) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }
        
        String pathInfo = request.getPathInfo();
        
        try {
            if (pathInfo == null || pathInfo.equals("/") || pathInfo.equals("/dashboard")) {
                // 대시보드 메인 페이지
                showDashboard(request, response);
            } else if (pathInfo.equals("/settings")) {
                // 설정 관리 페이지
                showSettings(request, response);
            } else if (pathInfo.equals("/sales")) {
                // 매출 통계 페이지
                showSalesStats(request, response);
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (SQLException e) {
            throw new ServletException("Database error", e);
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html; charset=UTF-8");
        
        // 세션 체크
        HttpSession session = request.getSession();
        String authorization = (String) session.getAttribute("authorization");
        
        if (authorization == null || !authorization.equals("master")) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }
        
        String pathInfo = request.getPathInfo();
        
        try {
            if (pathInfo.equals("/updateSettings")) {
                // 요금 정책 수정
                updateFeePolicy(request, response);
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (SQLException e) {
            throw new ServletException("Database error", e);
        }
    }
    
    /**
     * 대시보드 메인 페이지 표시
     */
    private void showDashboard(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException, SQLException {
        
        // 요약 통계 조회
        Map<String, Object> summary = adminDAO.getSummaryStats();
        request.setAttribute("summary", summary);
        
        // 차종별 통계 조회
        Map<String, Integer> vehicleStats = adminDAO.getVehicleTypeStats();
        request.setAttribute("vehicleStats", vehicleStats);
        
        // 최근 일별 매출 (7일)
        List<SalesStats> recentSales = adminDAO.getDailySales();
        if (recentSales.size() > 7) {
            recentSales = recentSales.subList(0, 7);
        }
        request.setAttribute("recentSales", recentSales);
        
        request.getRequestDispatcher("/WEB-INF/views/admin/dashboard.jsp").forward(request, response);
    }
    
    /**
     * 설정 관리 페이지 표시
     */
    private void showSettings(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException, SQLException {
        
        // 현재 요금 정책 조회
        FeePolicy policy = adminDAO.getCurrentFeePolicy();
        request.setAttribute("policy", policy);
        
        request.getRequestDispatcher("/WEB-INF/views/admin/settings.jsp").forward(request, response);
    }
    
    /**
     * 매출 통계 페이지 표시
     */
    private void showSalesStats(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException, SQLException {
        
        String type = request.getParameter("type");
        if (type == null) type = "daily";
        
        if (type.equals("daily")) {
            // 일별 매출 통계
            List<SalesStats> dailySales = adminDAO.getDailySales();
            request.setAttribute("salesData", dailySales);
            request.setAttribute("type", "daily");
        } else if (type.equals("monthly")) {
            // 월별 매출 통계
            List<SalesStats> monthlySales = adminDAO.getMonthlySales();
            request.setAttribute("salesData", monthlySales);
            request.setAttribute("type", "monthly");
        }
        
        // 차종별 통계
        Map<String, Integer> vehicleStats = adminDAO.getVehicleTypeStats();
        request.setAttribute("vehicleStats", vehicleStats);
        
        request.getRequestDispatcher("/WEB-INF/views/admin/sales.jsp").forward(request, response);
    }
    
    /**
     * 요금 정책 수정 처리
     */
    private void updateFeePolicy(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException, SQLException {
        
        try {
            // 현재 정책 조회
            FeePolicy policy = adminDAO.getCurrentFeePolicy();
            
            // 파라미터에서 값 가져오기
            int baseFee = Integer.parseInt(request.getParameter("baseFee"));
            int basicUnitMinute = Integer.parseInt(request.getParameter("basicUnitMinute"));
            int unitFee = Integer.parseInt(request.getParameter("unitFee"));
            int billingUnitMinutes = Integer.parseInt(request.getParameter("billingUnitMinutes"));
            int helpDiscountRate = Integer.parseInt(request.getParameter("helpDiscountRate"));
            int compactDiscountRate = Integer.parseInt(request.getParameter("compactDiscountRate"));
            int gracePeriodMinutes = Integer.parseInt(request.getParameter("gracePeriodMinutes"));
            int maxCapAmount = Integer.parseInt(request.getParameter("maxCapAmount"));
            
            // 정책 업데이트
            policy.setBaseFee(baseFee);
            policy.setBasicUnitMinute(basicUnitMinute);
            policy.setUnitFee(unitFee);
            policy.setBillingUnitMinutes(billingUnitMinutes);
            policy.setHelpDiscountRate(helpDiscountRate);
            policy.setCompactDiscountRate(compactDiscountRate);
            policy.setGracePeriodMinutes(gracePeriodMinutes);
            policy.setMaxCapAmount(maxCapAmount);
            
            boolean success = adminDAO.updateFeePolicy(policy);
            
            if (success) {
                request.setAttribute("message", "요금 정책이 성공적으로 수정되었습니다.");
                request.setAttribute("messageType", "success");
            } else {
                request.setAttribute("message", "요금 정책 수정에 실패했습니다.");
                request.setAttribute("messageType", "error");
            }
            
        } catch (NumberFormatException e) {
            request.setAttribute("message", "입력값이 올바르지 않습니다.");
            request.setAttribute("messageType", "error");
        }
        
        // 설정 페이지로 리다이렉트
        showSettings(request, response);
    }
}
