package com.parking.vo;

/**
 * 매출 통계 VO (Value Object)
 * 일별/월별 매출 통계 데이터를 담는 클래스
 */
public class SalesStats {
    private String period;          // 기간 (날짜 또는 월)
    private int totalAmount;        // 총 매출액
    private int totalCount;         // 총 차량 대수
    private int normalCount;        // 일반 차량 수
    private int compactCount;       // 경차 수
    private int disabledCount;      // 장애인 차량 수
    private int monthlyCount;       // 월정액 회원 수
    
    // 기본 생성자
    public SalesStats() {}
    
    // 생성자 (일별/월별 매출용)
    public SalesStats(String period, int totalAmount, int totalCount) {
        this.period = period;
        this.totalAmount = totalAmount;
        this.totalCount = totalCount;
    }
    
    // 전체 생성자
    public SalesStats(String period, int totalAmount, int totalCount, 
                     int normalCount, int compactCount, int disabledCount, int monthlyCount) {
        this.period = period;
        this.totalAmount = totalAmount;
        this.totalCount = totalCount;
        this.normalCount = normalCount;
        this.compactCount = compactCount;
        this.disabledCount = disabledCount;
        this.monthlyCount = monthlyCount;
    }
    
    // Getters and Setters
    public String getPeriod() {
        return period;
    }
    
    public void setPeriod(String period) {
        this.period = period;
    }
    
    public int getTotalAmount() {
        return totalAmount;
    }
    
    public void setTotalAmount(int totalAmount) {
        this.totalAmount = totalAmount;
    }
    
    public int getTotalCount() {
        return totalCount;
    }
    
    public void setTotalCount(int totalCount) {
        this.totalCount = totalCount;
    }
    
    public int getNormalCount() {
        return normalCount;
    }
    
    public void setNormalCount(int normalCount) {
        this.normalCount = normalCount;
    }
    
    public int getCompactCount() {
        return compactCount;
    }
    
    public void setCompactCount(int compactCount) {
        this.compactCount = compactCount;
    }
    
    public int getDisabledCount() {
        return disabledCount;
    }
    
    public void setDisabledCount(int disabledCount) {
        this.disabledCount = disabledCount;
    }
    
    public int getMonthlyCount() {
        return monthlyCount;
    }
    
    public void setMonthlyCount(int monthlyCount) {
        this.monthlyCount = monthlyCount;
    }
    
    @Override
    public String toString() {
        return "SalesStats{" +
                "period='" + period + '\'' +
                ", totalAmount=" + totalAmount +
                ", totalCount=" + totalCount +
                ", normalCount=" + normalCount +
                ", compactCount=" + compactCount +
                ", disabledCount=" + disabledCount +
                ", monthlyCount=" + monthlyCount +
                '}';
    }
}
