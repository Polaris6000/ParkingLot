# 스마트주차 관리 시스템 - 관리자 대시보드

## 📋 프로젝트 개요
웹 기반 스마트 주차 관리 시스템의 관리자 대시보드 구현
- 요금 정책 관리
- 매출 통계 (일별/월별)
- 차종별 이용 현황

## 🗂️ 파일 구조

```
parking-management-system/
│
├── src/main/java/com/parking/
│   ├── vo/                           # Value Object (데이터 객체)
│   │   ├── FeePolicy.java           # 요금 정책 VO
│   │   └── SalesStats.java          # 매출 통계 VO
│   │
│   ├── dao/                          # Data Access Object (DB 접근)
│   │   └── AdminDAO.java            # 관리자 대시보드 DAO
│   │
│   └── controller/                   # Servlet (컨트롤러)
│       └── AdminServlet.java        # 관리자 대시보드 서블릿
│
├── src/main/webapp/
│   ├── WEB-INF/views/admin/         # JSP 페이지
│   │   ├── dashboard.jsp            # 대시보드 메인
│   │   ├── settings.jsp             # 설정 관리
│   │   └── sales.jsp                # 매출 통계
│   │
│   └── css/
│       └── admin.css                # 관리자 페이지 스타일
│
└── init.sql                          # 데이터베이스 스키마
```

## 🔧 설치 및 설정

### 1. 데이터베이스 설정

```bash
# MariaDB 접속
mysql -u root -p

# 데이터베이스 생성 및 초기화
source init.sql

# 기본 요금 정책 데이터 삽입
INSERT INTO fee_policy (base_fee, basic_unit_minute, unit_fee, billing_unit_minutes, 
                       help_discount_rate, compact_discount_rate, grace_period_minutes, max_cap_amount)
VALUES (2000, 60, 1000, 30, 50, 30, 10, 15000);
```

### 2. 라이브러리 설정 (pom.xml)

```xml
<dependencies>
    <!-- MariaDB JDBC Driver -->
    <dependency>
        <groupId>org.mariadb.jdbc</groupId>
        <artifactId>mariadb-java-client</artifactId>
        <version>3.0.8</version>
    </dependency>
    
    <!-- Servlet API -->
    <dependency>
        <groupId>javax.servlet</groupId>
        <artifactId>javax.servlet-api</artifactId>
        <version>4.0.1</version>
        <scope>provided</scope>
    </dependency>
    
    <!-- JSP API -->
    <dependency>
        <groupId>javax.servlet.jsp</groupId>
        <artifactId>javax.servlet.jsp-api</artifactId>
        <version>2.3.3</version>
        <scope>provided</scope>
    </dependency>
    
    <!-- JSTL -->
    <dependency>
        <groupId>javax.servlet</groupId>
        <artifactId>jstl</artifactId>
        <version>1.2</version>
    </dependency>
</dependencies>
```

### 3. 웹 애플리케이션 배포

```bash
# 프로젝트 빌드
mvn clean package

# Tomcat에 배포
cp target/parking-management.war $CATALINA_HOME/webapps/
```

## 📊 주요 기능

### 1. 대시보드 (/admin/dashboard)
- 오늘/이번달 매출 요약
- 현재 주차 현황
- 최근 7일 매출 차트
- 차종별 이용 비율

### 2. 설정 관리 (/admin/settings)
- 기본 요금 설정 (기본요금, 기본시간)
- 추가 요금 설정 (단위시간, 단위요금)
- 할인 정책 (장애인, 경차)
- 회차 시간 및 일일 최대 요금

### 3. 매출 통계 (/admin/sales)
- 일별 매출 통계 (최근 30일)
- 월별 매출 통계 (최근 12개월)
- 차종별 이용 통계
- 엑셀 다운로드 기능

## 🔐 접근 권한

관리자 대시보드는 `authorization = 'master'` 권한이 있는 사용자만 접근 가능합니다.

```sql
-- 관리자 계정 생성 예시
INSERT INTO admin (id, password, name, email, authorization, authentication)
VALUES ('admin', 'admin123', '관리자', 'admin@parking.com', 'master', true);
```

## 📈 데이터베이스 쿼리 예시

### 일별 매출 조회
```sql
SELECT 
  DATE_FORMAT(pay_time, '%Y-%m-%d') as period,
  SUM(pay_log) as total_amount,
  COUNT(*) as total_count
FROM pay_logs
WHERE pay_time >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
GROUP BY DATE_FORMAT(pay_time, '%Y-%m-%d')
ORDER BY period DESC;
```

### 차종별 통계 조회
```sql
SELECT 
  kind_of_discount,
  COUNT(*) as count
FROM pay_logs
WHERE pay_time >= DATE_SUB(CURDATE(), INTERVAL 30 DAY)
GROUP BY kind_of_discount;
```

## 🎨 사용된 기술

- **Backend**: Java, JSP, Servlet, JDBC
- **Database**: MariaDB
- **Frontend**: HTML5, CSS3, JavaScript
- **Chart Library**: Chart.js 3.9.1
- **Pattern**: MVC (Model-View-Controller)

## 📱 화면 구성

### 대시보드
- 4개의 요약 카드 (오늘 매출, 이번달 매출, 현재 주차, 평균 단가)
- 일별 매출 라인 차트
- 차종별 도넛 차트
- 최근 매출 상세 테이블

### 설정 관리
- 요금 정책 입력 폼
- 실시간 정책 미리보기
- 요금 계산 예시 (일반/경차/장애인/회차)

### 매출 통계
- 일별/월별 탭 전환
- 매출 추이 복합 차트 (매출액 + 차량대수)
- 상세 테이블 + 합계
- 차종별 통계 (도넛 차트 + 테이블)
- CSV 다운로드 기능

## 🔍 테스트 방법

1. 서버 시작 후 관리자로 로그인
2. 대시보드 접속: `http://localhost:8080/admin/dashboard`
3. 요금 정책 수정 테스트
4. 매출 통계 조회 (일별/월별)

## 🐛 트러블슈팅

### DB 연결 오류
```java
// AdminDAO.java의 연결 정보 확인
private static final String URL = "jdbc:mariadb://localhost:3306/parking_lot";
private static final String USER = "admin";
private static final String PASSWORD = "8282";
```

### 차트가 표시되지 않는 경우
- Chart.js CDN 로드 확인
- 브라우저 콘솔에서 JavaScript 오류 확인
- 데이터가 없는 경우 확인

## 📝 개발 시 주의사항

1. **SQL Injection 방지**: PreparedStatement 사용
2. **세션 관리**: 관리자 권한 체크 필수
3. **입력값 검증**: 클라이언트/서버 양쪽 검증
4. **리소스 정리**: Connection, Statement, ResultSet 닫기
5. **예외 처리**: try-catch-finally 블록 사용

## 🚀 향후 개선 사항

- [ ] 페이징 처리 고도화
- [ ] 더 많은 통계 지표 추가
- [ ] 실시간 데이터 갱신 (WebSocket)
- [ ] 모바일 반응형 개선
- [ ] 데이터 백업/복원 기능

## 👥 팀 협업 가이드

### Git 사용법
```bash
# 브랜치 생성
git checkout -b feature/admin-dashboard

# 작업 후 커밋
git add .
git commit -m "feat: 관리자 대시보드 구현"

# 푸시
git push origin feature/admin-dashboard

# Pull Request 생성
```

### 코드 리뷰 체크리스트
- [ ] 코드 스타일 일관성
- [ ] 주석 및 문서화
- [ ] 예외 처리
- [ ] SQL Injection 방지
- [ ] 테스트 완료

## 📞 문의

프로젝트 관련 문의사항은 팀 리더에게 연락 바랍니다.
